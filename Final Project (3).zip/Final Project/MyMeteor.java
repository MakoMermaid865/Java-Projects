/**
 * Author: Ari Kinney
 * Project: Final Project - Meteorite Data Analysis
 */

//The is the main class for my meteor project all methods will be called from here
public class MyMeteor {
    public static void main(String[] args) {
        UserInterface ui = new UserInterface();
        ui.go();
    }
    
}
