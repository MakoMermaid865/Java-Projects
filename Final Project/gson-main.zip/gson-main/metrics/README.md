# metrics

This Maven module contains the source code for running internal benchmark tests against Gson.
