
//TODO: Create the Deck class so that it works with a collection of
//      generic card types that realize the ICard interface.
import java.util.*;

public class Deck {

}
