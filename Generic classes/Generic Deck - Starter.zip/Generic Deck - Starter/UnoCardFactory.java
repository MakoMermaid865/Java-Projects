import java.util.ArrayList;
import java.util.List;

public class UnoCardFactory {

    /**
     * Create a list of UnoCard objects that are found in an Uno deck.
     * 
     * @return a list of UnoCard objects found in an Uno deck.
     */
    public static List<UnoCard> createFullDeck() {

        // TODO: Complete the createFullDeck method.

    }
}
