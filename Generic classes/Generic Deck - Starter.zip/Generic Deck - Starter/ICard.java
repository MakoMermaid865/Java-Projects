// DO NOT make changes to this file.
public interface ICard {
    String display();
}
