//TODO: Complete the UnoCard class

public class UnoCard {
    public enum Color {
        RED, BLUE, GREEN, YELLOW, WILD
    }

    public enum Value {
        ZERO, ONE, TWO, THREE, FOUR, FIVE, SIX, SEVEN, EIGHT, NINE,
        SKIP, REVERSE, DRAW_TWO, WILD, WILD_DRAW_FOUR
    }

}
